import json

from scanners.security_group_scanner import (
    scan_security_groups
)

from scanners.iam_scanner import (
    scan_iam_users
)

from services.findings_service import (
    save_finding
)

from services.alert_service import (
    send_alert
)


def lambda_handler(event, context):

    findings = []

    # Security Group Findings
    findings.extend(
        scan_security_groups()
    )

    # IAM Findings
    findings.extend(
        scan_iam_users()
    )

    # Temporary Test Finding
    # Remove later when real findings exist
    if not findings:

        findings.append(
            {
                "severity": "LOW",
                "resource_type": "SYSTEM",
                "resource_id": "TEST",
                "title": "Scanner Connectivity Test",
                "description":
                    "Generated for DynamoDB validation"
            }
        )

    # Persist Findings
    for finding in findings:

        save_finding(finding)

        # Send alerts only for critical findings
        if finding["severity"] == "CRITICAL":

            send_alert(finding)

    print(
        f"Security Findings Found: {len(findings)}"
    )

    return {
        "statusCode": 200,
        "body": json.dumps(
            {
                "findings": len(findings)
            }
        )
    }